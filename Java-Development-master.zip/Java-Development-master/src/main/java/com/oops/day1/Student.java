package com.oops.day1;

public class Student {
    private String name; // state variable

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }
}
