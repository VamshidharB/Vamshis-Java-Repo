package com.oops.day1;

public class Main1 {
    public static void main(String[] args) {
        Student s = new Student();

        // Set the student's name using the setter method
        s.setName("Ravi Chandra Alathuru");

        // Get the student's name using the getter method and print it
        System.out.println("Student's name: " + s.getName());
    }
}
