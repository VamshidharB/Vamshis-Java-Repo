package com.oops.day1;

class Animal {
    void eat(){
        System.out.println("Just Eating");

    }
}
