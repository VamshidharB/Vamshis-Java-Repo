package com.oops.day3;

interface A{
    void hi();


}
interface B{
    void bye();

}